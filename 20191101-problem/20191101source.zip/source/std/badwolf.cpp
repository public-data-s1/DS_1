#include<bits/stdc++.h>
using namespace std;
const int MAXN = 45;
const int MAXM = 305;
const int P = 1e9 + 7;
const int dx[4] = {1, -1, 0, 0};
const int dy[4] = {0, 0, 1, -1};
typedef long long ll;
typedef long double ld;
typedef unsigned long long ull;
template <typename T> void chkmax(T &x, T y) {x = max(x, y); }
template <typename T> void chkmin(T &x, T y) {x = min(x, y); } 
template <typename T> void read(T &x) {
	x = 0; int f = 1;
	char c = getchar();
	for (; !isdigit(c); c = getchar()) if (c == '-') f = -f;
	for (; isdigit(c); c = getchar()) x = x * 10 + c - '0';
	x *= f;
}
template <typename T> void write(T x) {
	if (x < 0) x = -x, putchar('-');
	if (x > 9) write(x / 10);
	putchar(x % 10 + '0');
}
template <typename T> void writeln(T x) {
	write(x);
	puts("");
}
int n, m, ans[MAXM];
bool vis[MAXN][MAXN];
vector <pair <int, int>> cur, lft;
pair <int, int> a[MAXN][MAXN];
pair <int, int> operator * (pair <int, int> x, pair <int, int> y) {
	return make_pair(1ll * x.first * y.first % P, x.second + y.second);
}
void update(int &x, int y) {
	x += y;
	if (x >= P) x -= P;
}
void work() {
	if (cur.size() == n) {
		int Minx = n, Miny = 1;
		for (auto x : cur) {
			chkmin(Minx, x.first);
			chkmin(Miny, x.second);
		}
		pair <int, int> res = make_pair(1, 0);
		for (auto x : cur) {
			res = res * a[x.first - Minx][x.second - Miny];
		}
		update(ans[res.second], res.first);
		return;
	}
	if (lft.size() == 0) return;
	pair <int, int> pos = lft.back();
	lft.pop_back(), work();
	int cnt = 0;
	cur.push_back(pos);
	for (int i = 0; i <= 3; i++) {
		int tx = pos.first + dx[i];
		int ty = pos.second + dy[i];
		if (vis[tx][ty]) {
			vis[tx][ty] = false, cnt++;
			lft.emplace_back(tx, ty);
		}
	}
	work();
	while (cnt--) {
		int tx = lft.back().first;
		int ty = lft.back().second;
		lft.pop_back();
		vis[tx][ty] = true;
	}
	cur.pop_back();
	lft.push_back(pos);
}
int main() {
	freopen("badwolf.in", "r", stdin);
	freopen("badwolf.out", "w", stdout);
	read(n), read(m);
	for (int i = 0; i <= n - 1; i++)
	for (int j = 0; j <= n - 1; j++) {
		read(a[i][j].first);
		read(a[i][j].second);
	}
	for (int i = 1; i <= 2 * n; i++)
	for (int j = 1; j <= n; j++)
		if (j != 1 || i > n) vis[i][j] = true;
	lft.emplace_back(n, 1), work();
	for (int i = 0; i <= m; i++)
		printf("%d ", ans[i]);
	printf("\n");
	return 0;
}
