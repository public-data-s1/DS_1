#include<bits/stdc++.h>
#define ll long long
using namespace std;
template<typename tn> void read(tn &a){
	tn x=0,f=1; char c=' ';
	for(;!isdigit(c);c=getchar()) if(c=='-') f=-1;
	for(;isdigit(c);c=getchar()) x=x*10+c-'0';
	a=x*f;
}
const int mod = 1e9+7;
const int dx[]={0,1,0,-1},dy[]={1,0,-1,0};
int n,m,a[50][50],b[50][50],vis[50][50],top;
struct node{
	int x,y;
}st[50];
ll ans[310];
void calc(int mnx,int mny){
	//cerr<<"*************\n";
	mnx--;mny--;
	int p1=1,p2=0;
	for(int i=1;i<=n;i++)
		p1=1ll*p1*a[st[i].x-mnx][st[i].y-mny]%mod,
		p2+=b[st[i].x-mnx][st[i].y-mny];
	//	cerr<<st[i].x-mnx<<' '<<st[i].y-mny<<'\n';
	ans[p2]=(ans[p2]+p1)%mod;
}
void Search(int x,int y,int k,int now,int mnx,int mny){
	mnx=min(mnx,x);mny=min(mny,y);
	st[++top]={x,y};
	vis[x][y]=top;
	for(int i=0;i<4;i++){
		int tx=x+dx[i],ty=y+dy[i];
		if(vis[tx][ty]) continue;
		vis[tx][ty]=-top;
	}
	if(top<n){
		for(int i=k;i<=top;i++){
			int px=st[i].x,py=st[i].y;
			for(int j=i==k?now:0;j<4;j++){
				int tx=px+dx[j],ty=py+dy[j];
				if(tx<n||tx==n&&ty<n||vis[tx][ty]&&vis[tx][ty]>-i) continue;
				if(j<3) Search(tx,ty,i,j+1,mnx,mny);
				else Search(tx,ty,i+1,0,mnx,mny);
			}
		}
	}
	else calc(mnx,mny);
	int mn=n+1;
	for(int i=0;i<4;i++){
		int tx=x+dx[i],ty=y+dy[i];
		if(vis[tx][ty]>0) mn=min(mn,vis[tx][ty]);
		if(vis[tx][ty]==-top) vis[tx][ty]=0;
	}
	top--;
	vis[x][y]=mn<=n?-mn:0;
}
int main(){
	freopen("badwolf.in","r",stdin);
	freopen("badwolf.out","w",stdout);
	read(n);read(m);
	for(int i=1;i<=n;i++)
		for(int j=1;j<=n;j++)
			read(a[i][j]),read(b[i][j]);
	Search(n,n,1,0,n,n);
	for(int i=0;i<=m;i++)
		cout<<(ans[i]+mod)%mod<<" \n"[i==m];
	return 0;
}
