#include<bits/stdc++.h>
#define ll long long
using namespace std;
template<typename tn> void read(tn &a){
	tn x=0,f=1; char c=' ';
	for(;!isdigit(c);c=getchar()) if(c=='-') f=-1;
	for(;isdigit(c);c=getchar()) x=x*10+c-'0';
	a=x*f;
}
const int N = 201000;
int s[N],hs[N],col[N],n,m,Q,typ,dep[N];
vector<int> e[N];
void dfs(int x,int dad){
	s[x]=1;dep[x]=dep[dad]+1;
	for(int v:e[x]) if(v!=dad){
		dfs(v,x);s[x]+=s[v];
		if(s[v]>s[hs[x]]||!hs[x]) hs[x]=v;
	}
}
struct node{int v[2];};
node operator * (node a,node b){
	return (node){a.v[1]<=b.v[0]?a.v[1]:max(b.v[0],a.v[0]),a.v[1]<=b.v[1]?a.v[1]:max(b.v[1],a.v[0])};
}
struct BST{
	int ch[N][2],fa[N],p[N],ps[N],B[N][2],W[N][2],cnt,vis[N];
	node ms[N],mt[N];
	unordered_map<int,int> h[N];
	bool nr(int x){return ch[fa[x]][0]==x||ch[fa[x]][1]==x;}
	void pushup(int x){
		ms[x]=mt[x];
		if(ch[x][0]) ms[x]=ms[ch[x][0]]*ms[x];
		if(ch[x][1]) ms[x]=ms[x]*ms[ch[x][1]];
	}
	void add(int x,int y,int tag){
		h[x][ms[y].v[0]]+=tag;
		for(int k:{0,1}){
			if(ms[y].v[0]<mt[x].v[k]) W[x][k]+=tag;
			else B[x][k]+=tag;
			while(B[x][k]-W[x][k]<mt[x].v[k]){
				int s=h[x][--mt[x].v[k]];
				B[x][k]+=s;W[x][k]-=s;
			}
			while(B[x][k]-W[x][k]-2*h[x][mt[x].v[k]]>=mt[x].v[k]+1){
				int s=h[x][mt[x].v[k]++];
				B[x][k]-=s;W[x][k]+=s;
			}
		}
	}
	int solve(int l,int r,int dad){
		int sum=0,now=ps[l];
		for(int i=l;i<=r;i++) sum+=ps[i];
		for(int i=l;i<=r;now+=ps[++i])
			if(now*2>sum){
				fa[p[i]]=dad;
				if(i>l) ch[p[i]][0]=solve(l,i-1,p[i]);
				if(i<r) ch[p[i]][1]=solve(i+1,r,p[i]);
				return pushup(p[i]),p[i];
			}
	}
	int build(int x,int dad){
		for(int i=x;i;i=hs[i]) vis[i]=1;
		for(int i=x;i;i=hs[i])
			for(int v:e[i]) if(!vis[v]) add(i,build(v,i),1);
		cnt=0;
		for(int i=x;i;i=hs[i]) p[++cnt]=i,ps[cnt]=s[i]-s[hs[i]];
		return solve(1,cnt,dad);
	}
	void debug(){
		cerr<<"***************************\n";
		for(int i=1;i<=n;i++)
			cerr<<mt[i].v[0]<<' '<<mt[i].v[1]<<' '<<ms[i].v[0]<<' '<<ms[i].v[1]<<'\n';
	}
	void modify(int x,int P){
		if(mt[x].v[0]>=0==P) return;
		if(P==0) mt[x]={-n-1,-n-1};
		if(P==1) mt[x]={n,n};
		for(;x;x=fa[x])
			if(!fa[x]||nr(x)) pushup(x);
			else{
				int y=fa[x];
				add(y,x,-1);pushup(x);add(y,x,1);
			}
	}
	node query(int x,int K){
		if(dep[x]<K) return query(ch[x][1],K);
		node ans=mt[x];
		if(ch[x][1]) ans=ans*ms[ch[x][1]];
		if(dep[x]>K) ans=query(ch[x][0],K)*ans;
		return ans;
	}
}T;
int main(){
	freopen("moment.in","r",stdin);
	freopen("moment.out","w",stdout);
	int NUM;read(NUM);
	read(n);read(Q);read(typ);
	for(int i=2;i<=n;i++){
		int x;read(x);
		e[x].push_back(i);
		e[i].push_back(x);
	}
	for(int i=1;i<=n;i++) read(col[i]);
	for(int i=1;i<=n;i++){
		if(col[i]==-1) T.mt[i]={-1,1},T.W[i][0]++,T.B[i][1]++;
		if(col[i]==0) T.mt[i]={-n-1,-n-1};
		if(col[i]==1) T.mt[i]={n,n};
	}
	dfs(1,0);
	T.build(1,0);
	int lst=0;
	while(Q--){
		int opt,x,y;read(opt);read(x);read(y);
		x^=lst;
		if(opt==1){
			int tp=x;
			while(T.nr(tp)) tp=T.fa[tp];
			int k=T.query(tp,dep[x]).v[0];
			cout<<(y<=k)<<'\n';
			if(y<=k) lst=x;
		}
		else T.modify(x,y);
		lst*=typ;
	}
	return 0;
}
