#include<bits/stdc++.h>
#define ll long long
using namespace std;
template<typename tn> void read(tn &a){
	tn x=0,f=1; char c=' ';
	for(;!isdigit(c);c=getchar()) if(c=='-') f=-1;
	for(;isdigit(c);c=getchar()) x=x*10+c-'0';
	a=x*f;
}
const int mod = 998244353;
ll fp(ll a,ll k){
	ll ans=1;
	for(;k;k>>=1,a=a*a%mod)
		if(k&1) ans=a*ans%mod;
	return ans;
}
int n,m,K,st[1010],top;
ll fac[1010],ifac[1010],f[1010],g[1010],ans,inv[1010];
void calc(){
	ll cef=fac[n],now=0;
	for(int i=1;i<=top;i++){
		now++;
		if(i==top||st[i]!=st[i+1]) cef=cef*ifac[now]%mod,now=0;
		cef=cef*inv[st[i]]%mod;
	}
	for(int i=1;i<=m;i++){
		g[i]=0;
		for(int j=1;j<=top;j++)
			g[i]+=__gcd(i,st[j]);
		g[i]=fp(K,g[i])*inv[i]%mod;
	}
	memset(f,0,sizeof(f));
	f[m]=fac[m]*cef%mod;
	for(int i=m;i;i--){
		for(int j=1;j<=m;j++){
			if(!f[j]) continue;
			ll p=1;
			for(int k=1;i*k<=j;k++){
				p=p*g[i]%mod*inv[k]%mod;
				f[j-i*k]=(f[j-i*k]+p*f[j])%mod;
			}
		}
	}
	ans=(ans+f[0])%mod;
}
void solve(int now,int lim){
	if(!now){calc();return;}
	for(int i=min(now,lim);i;i--){
		st[++top]=i;
		solve(now-i,i);
		top--;
	}
}
int main(){
	freopen("hybrid.in","r",stdin);
	freopen("hybrid.out","w",stdout);
	read(n);read(m);read(K);
	if(n>m) swap(n,m);
	inv[1]=1;
	for(int i=2;i<=1000;i++) inv[i]=inv[mod%i]*-(mod/i)%mod;
	fac[0]=1;ifac[0]=1;
	for(int i=1;i<=1000;i++) fac[i]=fac[i-1]*i%mod,ifac[i]=ifac[i-1]*inv[i]%mod;
	solve(n,n);
	ans=ans*ifac[n]%mod*ifac[m]%mod;
	cout<<(ans+mod)%mod<<'\n';
	return 0;
}
